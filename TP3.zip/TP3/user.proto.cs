syntax = "proto3";

message User {
  int32 id = 1;
  string name = 2;
}
